//
//  ALWCollectionViewCell.m
//  WeatherObjC
//
//  Created by Audrey Welch on 3/4/19.
//  Copyright © 2019 Lambda School. All rights reserved.
//

#import "ALWCollectionViewCell.h"

@implementation ALWCollectionViewCell

@end
